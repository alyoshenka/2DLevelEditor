Instructions for starting Level Player

Read Documentation.txt

Run Application -> LevelEditor.exe